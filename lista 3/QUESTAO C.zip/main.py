S = 1
P = 1
while P!= '#':
  P,S = input().split()
  S = int(S)
  if S >= 90 :
    acao = 'Alta'
    print(P,acao)
  elif S < 90 and P!='#' :
    acao = 'Internar'
    print(P,acao)
  

    